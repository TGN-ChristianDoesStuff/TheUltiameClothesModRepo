
package net.mcreator.theultimateclothesmod.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.block.BlockState;

import net.mcreator.theultimateclothesmod.itemgroup.ClothesItemGroup;
import net.mcreator.theultimateclothesmod.TheultimateclothesmodModElements;

@TheultimateclothesmodModElements.ModElement.Tag
public class Red_FabricItem extends TheultimateclothesmodModElements.ModElement {
	@ObjectHolder("theultimateclothesmod:red_fabric")
	public static final Item block = null;
	public Red_FabricItem(TheultimateclothesmodModElements instance) {
		super(instance, 14);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}
	public static class ItemCustom extends Item {
		public ItemCustom() {
			super(new Item.Properties().group(ClothesItemGroup.tab).maxStackSize(10));
			setRegistryName("red_fabric");
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public int getUseDuration(ItemStack itemstack) {
			return 0;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, BlockState par2Block) {
			return 1F;
		}
	}
}
