
package net.mcreator.theultimateclothesmod.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import net.mcreator.theultimateclothesmod.block.FabricPlantBlock;
import net.mcreator.theultimateclothesmod.TheultimateclothesmodModElements;

@TheultimateclothesmodModElements.ModElement.Tag
public class ClothesItemGroup extends TheultimateclothesmodModElements.ModElement {
	public ClothesItemGroup(TheultimateclothesmodModElements instance) {
		super(instance, 11);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabclothes") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(FabricPlantBlock.block, (int) (1));
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundImageName("item_search.png");
	}
	public static ItemGroup tab;
}
