
package net.mcreator.theultimateclothesmod.item;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;

import net.minecraft.util.ResourceLocation;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.Item;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;

import net.mcreator.theultimateclothesmod.creativetab.TabClothes;
import net.mcreator.theultimateclothesmod.ElementsTheUltimateClothesMod;

@ElementsTheUltimateClothesMod.ModElement.Tag
public class ItemSuitArmor extends ElementsTheUltimateClothesMod.ModElement {
	@GameRegistry.ObjectHolder("theultimateclothesmod:suitarmorhelmet")
	public static final Item helmet = null;
	@GameRegistry.ObjectHolder("theultimateclothesmod:suitarmorbody")
	public static final Item body = null;
	@GameRegistry.ObjectHolder("theultimateclothesmod:suitarmorlegs")
	public static final Item legs = null;
	@GameRegistry.ObjectHolder("theultimateclothesmod:suitarmorboots")
	public static final Item boots = null;
	public ItemSuitArmor(ElementsTheUltimateClothesMod instance) {
		super(instance, 1);
	}

	@Override
	public void initElements() {
		ItemArmor.ArmorMaterial enuma = EnumHelper.addArmorMaterial("SUITARMOR", "theultimateclothesmod:suit", 117, new int[]{2, 6, 5, 2}, 0,
				(net.minecraft.util.SoundEvent) net.minecraft.util.SoundEvent.REGISTRY.getObject(new ResourceLocation("entity.lightning.thunder")),
				0f);
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.CHEST).setUnlocalizedName("suitarmorbody")
				.setRegistryName("suitarmorbody").setCreativeTab(TabClothes.tab));
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.LEGS).setUnlocalizedName("suitarmorlegs")
				.setRegistryName("suitarmorlegs").setCreativeTab(TabClothes.tab));
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.FEET).setUnlocalizedName("suitarmorboots")
				.setRegistryName("suitarmorboots").setCreativeTab(TabClothes.tab));
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void registerModels(ModelRegistryEvent event) {
		ModelLoader.setCustomModelResourceLocation(body, 0, new ModelResourceLocation("theultimateclothesmod:suitarmorbody", "inventory"));
		ModelLoader.setCustomModelResourceLocation(legs, 0, new ModelResourceLocation("theultimateclothesmod:suitarmorlegs", "inventory"));
		ModelLoader.setCustomModelResourceLocation(boots, 0, new ModelResourceLocation("theultimateclothesmod:suitarmorboots", "inventory"));
	}
}
