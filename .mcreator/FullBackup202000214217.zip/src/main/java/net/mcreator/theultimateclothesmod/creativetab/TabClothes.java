
package net.mcreator.theultimateclothesmod.creativetab;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;
import net.minecraft.creativetab.CreativeTabs;

import net.mcreator.theultimateclothesmod.ElementsTheUltimateClothesMod;

@ElementsTheUltimateClothesMod.ModElement.Tag
public class TabClothes extends ElementsTheUltimateClothesMod.ModElement {
	public TabClothes(ElementsTheUltimateClothesMod instance) {
		super(instance, 11);
	}

	@Override
	public void initElements() {
		tab = new CreativeTabs("tabclothes") {
			@SideOnly(Side.CLIENT)
			@Override
			public ItemStack getTabIconItem() {
				return new ItemStack(Items.LEATHER_CHESTPLATE, (int) (1));
			}

			@SideOnly(Side.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundImageName("item_search.png");
	}
	public static CreativeTabs tab;
}
