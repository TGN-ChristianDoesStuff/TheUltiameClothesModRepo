
package net.mcreator.theultimateclothesmod.item;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;

import net.minecraft.util.ResourceLocation;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.Item;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;

import net.mcreator.theultimateclothesmod.creativetab.TabClothes;
import net.mcreator.theultimateclothesmod.ElementsTheUltimateClothesMod;

@ElementsTheUltimateClothesMod.ModElement.Tag
public class ItemYellow_clothes_2Armor extends ElementsTheUltimateClothesMod.ModElement {
	@GameRegistry.ObjectHolder("theultimateclothesmod:yellow_clothes_2armorhelmet")
	public static final Item helmet = null;
	@GameRegistry.ObjectHolder("theultimateclothesmod:yellow_clothes_2armorbody")
	public static final Item body = null;
	@GameRegistry.ObjectHolder("theultimateclothesmod:yellow_clothes_2armorlegs")
	public static final Item legs = null;
	@GameRegistry.ObjectHolder("theultimateclothesmod:yellow_clothes_2armorboots")
	public static final Item boots = null;
	public ItemYellow_clothes_2Armor(ElementsTheUltimateClothesMod instance) {
		super(instance, 89);
	}

	@Override
	public void initElements() {
		ItemArmor.ArmorMaterial enuma = EnumHelper.addArmorMaterial("YELLOW_CLOTHES_2ARMOR", "theultimateclothesmod:yellow_clothes_2", 15,
				new int[]{2, 6, 5, 2}, 9, (net.minecraft.util.SoundEvent) net.minecraft.util.SoundEvent.REGISTRY.getObject(new ResourceLocation("")),
				0f);
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.HEAD).setUnlocalizedName("yellow_clothes_2armorhelmet")
				.setRegistryName("yellow_clothes_2armorhelmet").setCreativeTab(TabClothes.tab));
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.CHEST).setUnlocalizedName("yellow_clothes_2armorbody")
				.setRegistryName("yellow_clothes_2armorbody").setCreativeTab(TabClothes.tab));
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.LEGS).setUnlocalizedName("yellow_clothes_2armorlegs")
				.setRegistryName("yellow_clothes_2armorlegs").setCreativeTab(TabClothes.tab));
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.FEET).setUnlocalizedName("yellow_clothes_2armorboots")
				.setRegistryName("yellow_clothes_2armorboots").setCreativeTab(TabClothes.tab));
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void registerModels(ModelRegistryEvent event) {
		ModelLoader.setCustomModelResourceLocation(helmet, 0,
				new ModelResourceLocation("theultimateclothesmod:yellow_clothes_2armorhelmet", "inventory"));
		ModelLoader.setCustomModelResourceLocation(body, 0,
				new ModelResourceLocation("theultimateclothesmod:yellow_clothes_2armorbody", "inventory"));
		ModelLoader.setCustomModelResourceLocation(legs, 0,
				new ModelResourceLocation("theultimateclothesmod:yellow_clothes_2armorlegs", "inventory"));
		ModelLoader.setCustomModelResourceLocation(boots, 0,
				new ModelResourceLocation("theultimateclothesmod:yellow_clothes_2armorboots", "inventory"));
	}
}
