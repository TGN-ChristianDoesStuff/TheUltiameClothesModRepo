
package net.mcreator.theultimateclothesmod.item;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;

import net.minecraft.util.ResourceLocation;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.Item;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;

import net.mcreator.theultimateclothesmod.creativetab.TabClothes;
import net.mcreator.theultimateclothesmod.ElementsTheUltimateClothesMod;

@ElementsTheUltimateClothesMod.ModElement.Tag
public class ItemGreen_ClothesArmor extends ElementsTheUltimateClothesMod.ModElement {
	@GameRegistry.ObjectHolder("theultimateclothesmod:green_clothesarmorhelmet")
	public static final Item helmet = null;
	@GameRegistry.ObjectHolder("theultimateclothesmod:green_clothesarmorbody")
	public static final Item body = null;
	@GameRegistry.ObjectHolder("theultimateclothesmod:green_clothesarmorlegs")
	public static final Item legs = null;
	@GameRegistry.ObjectHolder("theultimateclothesmod:green_clothesarmorboots")
	public static final Item boots = null;
	public ItemGreen_ClothesArmor(ElementsTheUltimateClothesMod instance) {
		super(instance, 44);
	}

	@Override
	public void initElements() {
		ItemArmor.ArmorMaterial enuma = EnumHelper.addArmorMaterial("GREEN_CLOTHESARMOR", "theultimateclothesmod:green_clothes", 15,
				new int[]{2, 6, 5, 2}, 9, (net.minecraft.util.SoundEvent) net.minecraft.util.SoundEvent.REGISTRY.getObject(new ResourceLocation("")),
				0f);
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.HEAD).setUnlocalizedName("green_clothesarmorhelmet")
				.setRegistryName("green_clothesarmorhelmet").setCreativeTab(TabClothes.tab));
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.CHEST).setUnlocalizedName("green_clothesarmorbody")
				.setRegistryName("green_clothesarmorbody").setCreativeTab(TabClothes.tab));
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.LEGS).setUnlocalizedName("green_clothesarmorlegs")
				.setRegistryName("green_clothesarmorlegs").setCreativeTab(TabClothes.tab));
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.FEET).setUnlocalizedName("green_clothesarmorboots")
				.setRegistryName("green_clothesarmorboots").setCreativeTab(TabClothes.tab));
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void registerModels(ModelRegistryEvent event) {
		ModelLoader.setCustomModelResourceLocation(helmet, 0,
				new ModelResourceLocation("theultimateclothesmod:green_clothesarmorhelmet", "inventory"));
		ModelLoader.setCustomModelResourceLocation(body, 0, new ModelResourceLocation("theultimateclothesmod:green_clothesarmorbody", "inventory"));
		ModelLoader.setCustomModelResourceLocation(legs, 0, new ModelResourceLocation("theultimateclothesmod:green_clothesarmorlegs", "inventory"));
		ModelLoader.setCustomModelResourceLocation(boots, 0, new ModelResourceLocation("theultimateclothesmod:green_clothesarmorboots", "inventory"));
	}
}
